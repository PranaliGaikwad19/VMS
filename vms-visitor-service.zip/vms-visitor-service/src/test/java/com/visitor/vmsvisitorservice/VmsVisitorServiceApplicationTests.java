package com.visitor.vmsvisitorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VmsVisitorServiceApplicationTests {

	@Test
	void contextLoads() {
		
	}

}
