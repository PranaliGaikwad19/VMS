package com.visitor.vmsvisitorservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VmsVisitorServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VmsVisitorServiceApplication.class, args);
	}

}
